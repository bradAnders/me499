Student:    Brad Anderson
Class:      ME 499
Assignment: Homework 1

No additional files to include.
Only used numpy and csv libraries
